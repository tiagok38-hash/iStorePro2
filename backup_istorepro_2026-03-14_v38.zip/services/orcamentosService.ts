import { supabase } from '../supabaseClient.ts';
import { clearCache, addAuditLog } from './mockApi.ts';
import { Orcamento, OrcamentoItem, OrcamentoStatus, AuditActionType, AuditEntityType } from '../types.ts';
import { getNowISO } from '../utils/dateUtils.ts';

/**
 * Retorna os orçamentos, aplicando filtros de permissão.
 * @param userId ID do vendedor atual. Se não passado (Admin), retorna todos.
 */
export const getOrcamentos = async (userId?: string): Promise<Orcamento[]> => {
    let query = supabase
        .from('orcamentos')
        .select(`
            *,
            itens:orcamento_itens(*)
        `)
        .order('created_at', { ascending: false });

    if (userId) {
        query = query.eq('vendedor_id', userId);
    }

    const { data, error } = await query;
    if (error) throw error;

    return data as unknown as Orcamento[];
};

/**
 * Cria um novo orçamento com seus itens.
 */
export const createOrcamento = async (
    orcamentoData: Partial<Orcamento>,
    itensData: Partial<OrcamentoItem>[],
    userId: string,
    userName: string
): Promise<Orcamento> => {
    // 1. Buscar último número para sequencial
    const { count } = await supabase
        .from('orcamentos')
        .select('*', { count: 'exact', head: true });

    const nextNumber = (count || 0) + 1;
    const formattedNumero = `#ORC-${nextNumber}`;

    // 1. Inserir Orçamento
    const { data: orcamento, error: orcErr } = await supabase
        .from('orcamentos')
        .insert([{
            ...orcamentoData,
            numero: orcamentoData.numero || formattedNumero,
            vendedor_id: userId,
            created_at: getNowISO(),
            updated_at: getNowISO()
        }])
        .select()
        .single();

    if (orcErr) throw orcErr;

    // 2. Transforma e insere Itens vinculados ao ID do novo Orçamento
    const itensToInsert = itensData.map(item => {
        const { id: _id, ...rest } = item as any;
        return {
            ...rest,
            orcamento_id: orcamento.id,
            created_at: getNowISO()
        };
    });

    if (itensToInsert.length > 0) {
        const { error: itensErr } = await supabase
            .from('orcamento_itens')
            .insert(itensToInsert);

        if (itensErr) {
            // Em caso de erro nos itens, seria ideal apagar o orçamento (rollback)
            await supabase.from('orcamentos').delete().eq('id', orcamento.id);
            throw itensErr;
        }
    }

    // 3. Busca completo para retornar
    const { data: finalOrcamento, error: fetchErr } = await supabase
        .from('orcamentos')
        .select('*, itens:orcamento_itens(*)')
        .eq('id', orcamento.id)
        .single();

    if (fetchErr) throw fetchErr;

    // Audit Log
    addAuditLog(
        AuditActionType.CREATE,
        AuditEntityType.ORCAMENTO,
        orcamento.id,
        `Orçamento ${orcamento.numero} criado para cliente ${orcamentoData.cliente_id || 'Avulso'}`,
        userId,
        userName
    ).catch(err => console.error('Failed to log orcamento create:', err));

    clearCache(['orcamentos']);

    return finalOrcamento as unknown as Orcamento;
};

/**
 * Atualiza um orçamento e seus itens.
 */
export const updateOrcamento = async (
    id: string,
    orcamentoData: Partial<Orcamento>,
    itensData: Partial<OrcamentoItem>[] // Deve conter tudo, pois recriaremos
): Promise<Orcamento> => {

    const { error: orcErr } = await supabase
        .from('orcamentos')
        .update({
            ...orcamentoData,
            updated_at: getNowISO()
        })
        .eq('id', id);

    if (orcErr) throw orcErr;

    // Atualiza Itens (Estratégia mais simples: apagar todos os itens antigos e recriar)
    // Isso evita lógica complexa de sync de array. O `id` do item mudará, mas para orçamento costuma ser OK.
    const { error: delErr } = await supabase
        .from('orcamento_itens')
        .delete()
        .eq('orcamento_id', id);

    if (delErr) throw delErr;

    const itensToInsert = itensData.map(item => {
        const { id: _id, ...rest } = item as any;
        return {
            ...rest,
            orcamento_id: id,
            created_at: getNowISO()
        };
    });

    if (itensToInsert.length > 0) {
        const { error: insErr } = await supabase
            .from('orcamento_itens')
            .insert(itensToInsert);
        if (insErr) throw insErr;
    }

    const { data: finalOrcamento, error: fetchErr } = await supabase
        .from('orcamentos')
        .select('*, itens:orcamento_itens(*)')
        .eq('id', id)
        .single();

    if (fetchErr) throw fetchErr;

    clearCache(['orcamentos']);
    return finalOrcamento as unknown as Orcamento;
};

/**
 * Atualiza status do Orçamento
 */
export const updateOrcamentoStatus = async (
    id: string,
    status: OrcamentoStatus,
    vendaId?: string
): Promise<void> => {
    const payload: Partial<Orcamento> = {
        status,
        updated_at: getNowISO()
    };

    if (status === 'convertido') {
        payload.convertido_em = getNowISO();
        if (vendaId) payload.venda_id = vendaId;
    }

    const { error } = await supabase
        .from('orcamentos')
        .update(payload)
        .eq('id', id);

    if (error) throw error;
    clearCache(['orcamentos']);
};

export const deleteOrcamento = async (id: string): Promise<void> => {
    // Delete items handled automatically by physical Cascade if setup in Postgres, 
    // but we can ensure here
    await supabase.from('orcamento_itens').delete().eq('orcamento_id', id);
    const { error } = await supabase.from('orcamentos').delete().eq('id', id);
    if (error) throw error;
    clearCache(['orcamentos']);
};

/**
 * Converte Orçamento -> Venda.
 * Reaproveita a function addSale existente no mockApi para manter toda a integridade 
 * de estoque, sessões de caixa e movimentação transacional já estabelecida.
 */
export const convertOrcamentoToSale = async (
    orcamento: Orcamento,
    userId: string,
    userName: string,
    openSessionId: string, // ID do caixa atual para vincular a venda
    openSessionDisplayId: number
): Promise<string> => {
    // Import delayed execution to prevent circular deps issues if any
    const { addSale } = await import('./mockApi.ts');

    if (!orcamento.itens || orcamento.itens.length === 0) {
        throw new Error("Orçamento não possui itens para conversão");
    }

    // Adaptando itens do Orçamento (OrcamentoItem) para formato de Items da Venda
    const adaptedItems = orcamento.itens.map(orcItem => {
        // Tentamos recuperar detalhes completos do produto para bater com as checagens do addSale
        // Se o produto não existir mais (deletado), a addSale pode rejeitar, mas passamos a key mínima.
        return {
            productId: orcItem.produto_id || 'unknown',
            quantity: orcItem.quantidade,
            unitPrice: orcItem.preco_unitario_snapshot,
            costPrice: orcItem.custo_snapshot || 0,
            discountValue: orcItem.desconto,
            discountType: 'R$',
            netTotal: orcItem.subtotal,
            // Detalhes estáticos salvos no momento do orçamento para não depender do banco atual:
            name: orcItem.nome_produto_snapshot,
            model: orcItem.sku_snapshot,
            isAccessory: orcItem.metadata_snapshot?.is_accessory || false,
            warrantyDays: orcItem.metadata_snapshot?.warranty_days || 0
        };
    });

    // Adaptando pagamentos baseado no snapshot do orçamento
    let adaptedPayments = [];
    const paymentSnap = orcamento.forma_pagamento_snapshot;

    if (paymentSnap && Array.isArray(paymentSnap.pagamentos) && paymentSnap.pagamentos.length > 0) {
        // Se houver a lista detalhada de pagamentos (novo padrão)
        adaptedPayments = paymentSnap.pagamentos.map((p: any) => ({
            ...p,
            id: p.id || `pay-conv-${Date.now()}-${Math.random()}`
        }));
    } else if (paymentSnap && paymentSnap.metodo) {
        // Fallback para padrão antigo (objeto único)
        adaptedPayments.push({
            id: `pay-conv-${Date.now()}`,
            method: paymentSnap.metodo || 'Outro',
            value: orcamento.total_final,
            installments: paymentSnap.parcelas || 1,
            isCreditInstallment: paymentSnap.metodo === 'Crediário'
        });
    } else {
        // Fallback total
        adaptedPayments.push({
            id: `pay-conv-${Date.now()}`,
            method: 'Dinheiro',
            value: orcamento.total_final,
            installments: 1
        });
    }

    // Construct the payload for addSale
    const salePayload = {
        customerId: orcamento.cliente_id,
        salespersonId: userId, // ESSENCIAL: Atribuir ao vendedor que converteu
        items: adaptedItems,
        payments: adaptedPayments,
        subtotal: orcamento.subtotal,
        total: orcamento.total_final,
        discountTotal: orcamento.desconto_total,
        interestTotal: orcamento.juros_total,
        observations: `Venda convertida do orçamento ${orcamento.numero}. \r\n${orcamento.observacoes || ''}`,
        cashSessionId: openSessionId,
        cashSessionDisplayId: openSessionDisplayId,
        warrantyTerm: 'Recibo de Venda' // Garantia padrão para conversão rápida
    };

    try {
        // 1. Aciona o engine já consolidado de Vendas (trata Estoque, Imeis, Sessões, Auditoria, Limites de Crédito)
        const newSale = await addSale(salePayload, userId, userName);

        // 2. Atualiza status do Orcamento
        await updateOrcamentoStatus(orcamento.id, 'convertido', newSale.id);

        // 3. Log de Auditoria da Conversão
        addAuditLog(
            AuditActionType.UPDATE,
            AuditEntityType.ORCAMENTO,
            orcamento.id,
            `Orçamento ${orcamento.numero} convertido em Venda #${newSale.id} por ${userName}`,
            userId,
            userName
        ).catch(err => console.error('Failed to log orcamento conversion:', err));

        return newSale.id;
    } catch (e: any) {
        throw new Error(`Erro na conversão: ${e.message}`);
    }
};
