import React, { createContext, useContext, useState, ReactNode, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../supabaseClient.ts';

export interface ChatMessage {
    id: string;
    sender_id: string;
    content: string;
    created_at: string;
    is_edited: boolean;
    edited_at: string | null;
    read_by: string[];
    conversation_id: string | null;
    sender_name?: string;
    sender_avatar?: string;
}

interface ChatContextData {
    isChatOpen: boolean;
    openChat: () => void;
    closeChat: () => void;
    toggleChat: () => void;
    messages: ChatMessage[];
    loading: boolean;
    loadingMore: boolean;
    hasMore: boolean;
    unreadCount: number;
    loadMore: () => Promise<void>;
    refetchMessages: () => Promise<void>;
    setCurrentUserId: (id: string | null) => void;
    typingUsers: string[];
    sendTypingEvent: (userName: string) => void;
}

const ChatContext = createContext<ChatContextData | undefined>(undefined);

const PAGE_SIZE = 30;

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [isChatOpen, setIsChatOpen] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState(false);
    const [hasMore, setHasMore] = useState(true);
    const [unreadCount, setUnreadCount] = useState(0);
    const subscriptionRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
    const oldestCreatedAtRef = useRef<string | null>(null);
    const lastOpenedRef = useRef<string | null>(null);
    const currentUserIdRef = useRef<string | null>(null);

    // Typing logic
    const [typingUsers, setTypingUsers] = useState<{ id: string, name: string }[]>([]);
    const typingTimeouts = useRef<{ [key: string]: NodeJS.Timeout }>({});
    const broadcastChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

    const messagesRef = useRef<ChatMessage[]>([]);
    useEffect(() => {
        messagesRef.current = messages;
    }, [messages]);

    // Salva o timestamp no localStorage de forma persistente e por usuário
    const saveLastOpened = useCallback((userId: string | null) => {
        if (!userId) return;
        const now = new Date().toISOString();
        lastOpenedRef.current = now;
        localStorage.setItem(`chat_last_read_at_${userId}`, now);
        // Mantém sessionStorage por compatibilidade temporária com outros componentes
        sessionStorage.setItem('chat_last_opened', now);
    }, []);

    // Init: recupera o último timestamp de abertura do chat (fallback para sessionStorage)
    useEffect(() => {
        if (currentUserIdRef.current) {
            const saved = localStorage.getItem(`chat_last_read_at_${currentUserIdRef.current}`) ||
                sessionStorage.getItem('chat_last_opened');
            lastOpenedRef.current = saved;
        }
    }, []);

    // Recalcula unreadCount sempre que chegam novas mensagens
    const recalcUnread = useCallback((msgs: ChatMessage[]) => {
        if (isChatOpen) {
            setUnreadCount(0);
            return;
        }
        let lastOpened = lastOpenedRef.current;
        const currentUserId = currentUserIdRef.current;

        // Se o usuário não possui lastOpened (dispositivo novo ou limpou o cache),
        // inicializamos com a data atual para evitar mostrar mensagens antigas indesejadas.
        if (!lastOpened && msgs.length > 0) {
            const now = new Date().toISOString();
            lastOpened = now;
            if (currentUserId) {
                lastOpenedRef.current = now;
                localStorage.setItem(`chat_last_read_at_${currentUserId}`, now);
            }
        }

        const count = msgs.filter(m => {
            if (m.sender_id === currentUserId) return false;
            if (!lastOpened) return false;
            return new Date(m.created_at).getTime() > new Date(lastOpened).getTime();
        }).length;
        setUnreadCount(count);
    }, [isChatOpen]);

    const setCurrentUserId = useCallback((id: string | null) => {
        if (currentUserIdRef.current === id) return; // Evita loop em App.tsx
        currentUserIdRef.current = id;
        if (id) {
            const saved = localStorage.getItem(`chat_last_read_at_${id}`) ||
                sessionStorage.getItem('chat_last_opened');
            lastOpenedRef.current = saved;
        } else {
            lastOpenedRef.current = null;
        }
        // Recalcula imediatamente com o novo ID do usuário (usando a ref atualizada)
        recalcUnread(messagesRef.current);
    }, [recalcUnread]);

    const openChat = useCallback(() => {
        setIsChatOpen(true);
        saveLastOpened(currentUserIdRef.current);
        setUnreadCount(0);
    }, [saveLastOpened]);

    const closeChat = useCallback(() => {
        setIsChatOpen(false);
    }, []);

    const toggleChat = useCallback(() => {
        setIsChatOpen(prev => {
            if (!prev) {
                saveLastOpened(currentUserIdRef.current);
                setUnreadCount(0);
            } else {
                // Quando fecha, garante salvar o timestamp para não marcar como "recebidas depois de fechar" 
                // mensagens que carregaram com ele aberto
                saveLastOpened(currentUserIdRef.current);
            }
            return !prev;
        });
    }, [saveLastOpened]);

    // Fetch paginado
    const fetchMessages = useCallback(async (before?: string): Promise<ChatMessage[]> => {
        try {
            let query = supabase
                .from('chat_messages')
                .select('*')
                .is('conversation_id', null)
                .order('created_at', { ascending: false })
                .limit(PAGE_SIZE);

            if (before) {
                query = query.lt('created_at', before);
            }

            const { data, error } = await query;
            if (error) throw error;
            if (!data || data.length === 0) {
                setHasMore(false);
                return [];
            }

            const sorted = [...data].reverse() as ChatMessage[];
            if (sorted.length < PAGE_SIZE) setHasMore(false);
            return sorted;
        } catch (err) {
            console.error('ChatContext: Erro ao buscar mensagens:', err);
            return [];
        }
    }, []);

    // Carregamento inicial
    useEffect(() => {
        let mounted = true;
        fetchMessages().then(initialMessages => {
            if (!mounted) return;
            setMessages(initialMessages);
            if (initialMessages.length > 0) {
                oldestCreatedAtRef.current = initialMessages[0].created_at;
            }
            setLoading(false);
            recalcUnread(initialMessages);
        });
        return () => { mounted = false; };
    }, [fetchMessages]);

    // Recalcula quando o chat abre/fecha ou quando chegarem novas mensagens
    useEffect(() => {
        recalcUnread(messages);

        // Se o chat estiver aberto e chegarem mensagens novas, atualizamos o timestamp de leitura
        if (isChatOpen && messages.length > 0) {
            const lastMsg = messages[messages.length - 1];
            // Se a última mensagem for posterior ao que temos salvo, atualizamos
            if (!lastOpenedRef.current || new Date(lastMsg.created_at).getTime() > new Date(lastOpenedRef.current).getTime()) {
                saveLastOpened(currentUserIdRef.current);
            }
        }
    }, [isChatOpen, recalcUnread, messages, saveLastOpened]);

    // Setup de Broadcast (Typing Indicator)
    useEffect(() => {
        const channel = supabase.channel('chat_broadcast', {
            config: { broadcast: { self: false } }
        });

        channel.on('broadcast', { event: 'typing' }, (payload) => {
            const { user_id, user_name } = payload.payload;
            if (!user_id || !user_name || user_id === currentUserIdRef.current) return;

            setTypingUsers(prev => {
                if (!prev.some(u => u.id === user_id)) {
                    return [...prev, { id: user_id, name: user_name }];
                }
                return prev;
            });

            if (typingTimeouts.current[user_id]) {
                clearTimeout(typingTimeouts.current[user_id]);
            }

            typingTimeouts.current[user_id] = setTimeout(() => {
                setTypingUsers(prev => prev.filter(u => u.id !== user_id));
                delete typingTimeouts.current[user_id];
            }, 3000);
        }).subscribe((status) => {
            if (status === 'SUBSCRIBED') {
                broadcastChannelRef.current = channel;
            }
        });

        return () => {
            channel.unsubscribe();
            Object.values(typingTimeouts.current).forEach(clearTimeout);
            broadcastChannelRef.current = null;
        };
    }, []);

    const sendTypingEvent = useCallback((userName: string) => {
        if (!broadcastChannelRef.current || !currentUserIdRef.current) return;
        broadcastChannelRef.current.send({
            type: 'broadcast',
            event: 'typing',
            payload: { user_id: currentUserIdRef.current, user_name: userName }
        });
    }, []);

    // Subscription Realtime — ÚNICO listener global para toda a app
    // NOTA: filtro 'conversation_id=is.null' NÃO é suportado pelo Supabase Realtime
    // Por isso escutamos todos os eventos da tabela e filtramos no cliente
    useEffect(() => {
        if (subscriptionRef.current) {
            subscriptionRef.current.unsubscribe();
        }

        const channel = supabase
            .channel('chat_global_ctx_v2')
            .on('postgres_changes', {
                event: 'INSERT',
                schema: 'public',
                table: 'chat_messages',
            }, (payload) => {
                const newMsg = payload.new as ChatMessage;
                // Filtrar no cliente: apenas mensagens do chat global
                if (newMsg.conversation_id) return;
                setMessages(prev => {
                    if (prev.some(m => m.id === newMsg.id)) return prev;
                    const updated = [...prev, newMsg];
                    recalcUnread(updated);
                    return updated;
                });
            })
            .on('postgres_changes', {
                event: 'UPDATE',
                schema: 'public',
                table: 'chat_messages',
            }, (payload) => {
                const updatedMsg = payload.new as ChatMessage;
                if (updatedMsg.conversation_id) return;
                setMessages(prev => prev.map(m => m.id === updatedMsg.id ? updatedMsg : m));
            })
            .subscribe();

        subscriptionRef.current = channel;

        return () => {
            channel.unsubscribe();
            subscriptionRef.current = null;
        };
    }, [recalcUnread]);

    const refetchMessages = useCallback(async () => {
        const fresh = await fetchMessages();
        setMessages(fresh);
        if (fresh.length > 0) {
            oldestCreatedAtRef.current = fresh[0].created_at;
        }
        setHasMore(fresh.length >= PAGE_SIZE);
        recalcUnread(fresh);
    }, [fetchMessages, recalcUnread]);

    const loadMore = useCallback(async () => {
        if (loadingMore || !hasMore || !oldestCreatedAtRef.current) return;
        setLoadingMore(true);
        const older = await fetchMessages(oldestCreatedAtRef.current);
        if (older.length > 0) {
            oldestCreatedAtRef.current = older[0].created_at;
            setMessages(prev => [...older, ...prev]);
        }
        setLoadingMore(false);
    }, [loadingMore, hasMore, fetchMessages]);

    return (
        <ChatContext.Provider value={{
            isChatOpen,
            openChat,
            closeChat,
            toggleChat,
            messages,
            loading,
            loadingMore,
            hasMore,
            unreadCount,
            loadMore,
            refetchMessages,
            setCurrentUserId,
            typingUsers: typingUsers.map(u => u.name),
            sendTypingEvent,
        }}>
            {children}
        </ChatContext.Provider>
    );
};

export const useChat = () => {
    const ctx = useContext(ChatContext);
    if (!ctx) throw new Error('useChat must be used within a ChatProvider');
    return ctx;
};

// ─── Hook auxiliar para envio de mensagens ─────────────────────────────────
export const useSendMessage = (senderId: string | null) => {
    const [sending, setSending] = useState(false);

    const sendMessage = useCallback(async (content: string): Promise<boolean> => {
        if (!senderId || !content.trim()) return false;
        setSending(true);
        try {
            const { error } = await supabase
                .from('chat_messages')
                .insert({ sender_id: senderId, content: content.trim(), conversation_id: null });
            if (error) throw error;
            return true;
        } catch (err: any) {
            console.error('Erro ao enviar:', err.message);
            return false;
        } finally {
            setSending(false);
        }
    }, [senderId]);

    const editMessage = useCallback(async (messageId: string, newContent: string): Promise<boolean> => {
        if (!senderId || !newContent.trim()) return false;
        setSending(true);
        try {
            const { error } = await supabase
                .from('chat_messages')
                .update({
                    content: newContent.trim(),
                    is_edited: true,
                    edited_at: new Date().toISOString(),
                })
                .eq('id', messageId)
                .eq('sender_id', senderId);
            if (error) throw error;
            return true;
        } catch (err: any) {
            console.error('Erro ao editar:', err.message);
            return false;
        } finally {
            setSending(false);
        }
    }, [senderId]);

    return { sending, sendMessage, editMessage };
};
