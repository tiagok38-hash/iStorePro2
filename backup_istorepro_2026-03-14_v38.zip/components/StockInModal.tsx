
import React, { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { PurchaseOrder, Product, PurchaseItem, ProductConditionParameter, StorageLocationParameter, WarrantyParameter } from '../types.ts';
import { useToast } from '../contexts/ToastContext.tsx';
import { useUser } from '../contexts/UserContext.tsx';
import { launchPurchaseToStock, formatCurrency, getProductConditions, getStorageLocations, getWarranties } from '../services/mockApi.ts';
import { SpinnerIcon, DocumentArrowUpIcon, XCircleIcon, BoltIcon, SearchIcon, ArchiveBoxIcon } from './icons.tsx';
import CurrencyInput from './CurrencyInput.tsx';
import StockSearchModal from './StockSearchModal.tsx';

type ItemDetail = {
    purchaseItemId: string;
    itemDescription: string;
    serialNumber: string;
    imei1: string;
    imei2: string;
    condition: string;
    batteryHealth: number;
    warranty: string;
    storageLocation?: string;
    costPrice: number;
    additionalCostPrice: number;
    markup: number | null;
    salePrice: number | null;
    wholesalePrice: number | null; // Preço de Atacado (ATC)
    quantity: number;
    minimumStock?: number;
    isApple?: boolean;
    barcode?: string;
    controlByBarcode?: boolean;
    hasImei?: boolean; // Indica se o item precisa de IMEI/Serial Number
};

const StockInModal: React.FC<{
    purchaseOrder: PurchaseOrder;
    onClose: (refresh: boolean) => void;
    allProducts: Product[];
    grades: any[];
    gradeValues: any[];
}> = ({ purchaseOrder, onClose, allProducts, grades, gradeValues }) => {
    const [details, setDetails] = useState<ItemDetail[]>([]);
    const [isSaving, setIsSaving] = useState(false);
    const [errors, setErrors] = useState<Record<number, boolean>>({});
    const [duplicateErrors, setDuplicateErrors] = useState<Record<number, Partial<Record<'serialNumber' | 'imei1' | 'imei2', boolean>>>>({});
    const [isMinimumStockEnabled, setIsMinimumStockEnabled] = useState(false);
    const { showToast } = useToast();
    const [isContinuousScanEnabled, setIsContinuousScanEnabled] = useState(false);
    const inputRefs = React.useRef<{ [key: string]: HTMLInputElement | null }>({});
    const { user } = useUser();

    // Dynamic parameters from Empresa > Parâmetros
    const [conditionOptions, setConditionOptions] = useState<ProductConditionParameter[]>([]);
    const [locationOptions, setLocationOptions] = useState<StorageLocationParameter[]>([]);
    const [warrantyOptions, setWarrantyOptions] = useState<WarrantyParameter[]>([]);

    // Component States
    const [showSearchModal, setShowSearchModal] = useState(false);

    // Fetch dynamic parameters on mount
    useEffect(() => {
        const fetchParameters = async () => {
            const [conditions, locations, warranties] = await Promise.all([
                getProductConditions(),
                getStorageLocations(),
                getWarranties()
            ]);
            setConditionOptions(conditions);
            setLocationOptions(locations);
            setWarrantyOptions(warranties);
        };
        fetchParameters();
    }, []);

    // Lock body scroll on mount
    useEffect(() => {
        document.body.style.overflow = 'hidden';
        return () => {
            document.body.style.overflow = 'auto';
        };
    }, []);

    // Determina o modo de renderização baseado nos itens da compra
    // Se QUALQUER item tem IMEI, usa o modo único para mostrar campos de IMEI/SN
    // Isso permite compras mistas (itens com e sem IMEI)
    const hasAnyImeiItem = useMemo(() =>
        purchaseOrder.items.some(item => item.hasImei),
        [purchaseOrder.items]);

    const isBulkMode = !hasAnyImeiItem;

    // Load/Save draft from localStorage
    useEffect(() => {
        if (details.length > 0) {
            localStorage.setItem(`stock_launch_draft_${purchaseOrder.id}`, JSON.stringify(details));
        }
    }, [details, purchaseOrder.id]);

    useEffect(() => {
        const launchedProductsForThisPO = allProducts.filter(p => p.purchaseOrderId === purchaseOrder.id);
        const expandedDetails = purchaseOrder.items.flatMap(item => {
            const launchedCount = launchedProductsForThisPO
                .filter(p => p.purchaseItemId === item.id)
                .reduce((sum, p) => sum + p.stock, 0);

            const quantityToLaunch = item.quantity - launchedCount;

            if (quantityToLaunch <= 0) {
                return [];
            }

            const baseDetail = {
                purchaseItemId: item.id,
                itemDescription: item.productDetails.model,
                serialNumber: '', imei1: '', imei2: '',
                condition: item.productDetails.condition || 'Novo',
                batteryHealth: item.productDetails.batteryHealth ?? 100,
                warranty: item.productDetails.warranty || '1 ano',
                storageLocation: item.productDetails.storageLocation || 'Loja Santa Cruz',
                costPrice: item.unitCost,
                additionalCostPrice: item.additionalUnitCost,
                markup: null, salePrice: null, wholesalePrice: null,
                minimumStock: item.minimumStock,
                isApple: item.productDetails.brand === 'Apple',
                barcode: (item.barcodes && item.barcodes.length > 0) ? item.barcodes[0] : '',
                controlByBarcode: item.controlByBarcode,
                hasImei: item.hasImei
            };

            // Decisão POR ITEM: se tem IMEI, expande em linhas individuais; se não, agrupa
            if (item.hasImei) {
                // Modo único: cada unidade é uma linha separada para preencher IMEI/SN
                return Array.from({ length: quantityToLaunch }, () => ({
                    ...baseDetail,
                    quantity: 1,
                }));
            } else {
                // Modo bulk: agrupa quantidade (produtos sem IMEI, como acessórios ou com código de barras)
                return [{
                    ...baseDetail,
                    quantity: quantityToLaunch,
                }];
            }
        });

        if (expandedDetails.length === 0 && details.length === 0) {
            showToast("Todos os itens desta compra já foram lançados no estoque.", "info");
            onClose(false);
            return;
        }

        setDetails(prev => {
            // Se já temos algo preenchido (mesmo queIMEIs vazios), não resetamos se virmos de um refresh de background
            if (prev.length > 0) return prev;

            // Tenta recuperar rascunho salvo
            const savedDraft = localStorage.getItem(`stock_launch_draft_${purchaseOrder.id}`);
            if (savedDraft) {
                try {
                    const parsed = JSON.parse(savedDraft);
                    if (Array.isArray(parsed) && parsed.length > 0) {
                        // Validate: Ensure all draft items still exist in the current purchase order
                        // This prevents crashes if the purchase was edited (changing item IDs) after the draft was saved
                        const allIdsValid = parsed.every(draftItem =>
                            purchaseOrder.items.some(pi => pi.id === draftItem.purchaseItemId)
                        );

                        if (allIdsValid) {
                            const parsedItemIds = new Set(parsed.map((d: any) => d.purchaseItemId));
                            const newItems = expandedDetails.filter((d: any) => !parsedItemIds.has(d.purchaseItemId));
                            return [...parsed, ...newItems];
                        } else {
                            console.warn("Draft discarded because some items no longer exist in the purchase order.");
                            // Optional: showToast("Rascunho descartado pois a compra foi modificada.", "info");
                        }
                    }
                } catch (e) {
                    console.error("Erro ao carregar rascunho", e);
                }
            }

            return expandedDetails;
        });

        const hasMinStockEnabled = expandedDetails.some(d => !d.isApple && d.minimumStock && d.minimumStock > 0);
        setIsMinimumStockEnabled(hasMinStockEnabled);
    }, [purchaseOrder, allProducts, onClose, showToast]);

    const focusNextRow = (index: number, field: string) => {
        // Use DOM ID for absolute reliability over React Refs
        const nextId = `stock-input-${index + 1}-${field}`;
        const nextInput = document.getElementById(nextId);

        if (nextInput) {
            // showToast(`Pulando para item #${index + 2}`, 'success'); // Optional feedback
            nextInput.focus();
            (nextInput as HTMLInputElement).select(); // Select all text in next input just in case
            nextInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            const currentId = `stock-input-${index}-${field}`;
            // Check if we are at the end
            if (index + 1 >= details.length) {
                showToast('Último item da lista preenchido!', 'success');
            } else {
                console.warn(`Could not find input with ID: ${nextId}`);
            }
        }
    };

    const handleDetailChange = (index: number, field: keyof ItemDetail, value: any) => {
        const newDetails = [...details];
        let detail = { ...newDetails[index] };

        // Clear duplicate error for this field if it exists
        if (duplicateErrors[index]?.[field as keyof typeof duplicateErrors[number]]) {
            const newErrors = { ...duplicateErrors };
            if (newErrors[index]) {
                delete newErrors[index]![field as keyof typeof duplicateErrors[number]];
                if (Object.keys(newErrors[index]!).length === 0) {
                    delete newErrors[index];
                }
                setDuplicateErrors(newErrors);
            }
        }

        if (field === 'markup') {
            const markupValue = value === '' ? null : parseFloat(String(value));
            if (isNaN(markupValue as number) && markupValue !== null) return;

            detail.markup = markupValue;
            const finalCost = detail.costPrice + detail.additionalCostPrice;
            if (finalCost > 0 && detail.markup !== null) {
                const calculatedPrice = finalCost * (1 + detail.markup / 100);
                detail.salePrice = parseFloat(calculatedPrice.toFixed(2));
                if (detail.salePrice > 0) {
                    setErrors(prev => ({ ...prev, [index]: false }));
                }
            }
        } else if (field === 'salePrice') {
            const salePriceValue = value === null ? null : Number(value);

            detail.salePrice = salePriceValue;
            const finalCost = detail.costPrice + detail.additionalCostPrice;
            if (finalCost > 0 && detail.salePrice !== null && detail.salePrice > 0) {
                const newMarkup = ((detail.salePrice / finalCost) - 1) * 100;
                detail.markup = isFinite(newMarkup) ? parseFloat(newMarkup.toFixed(2)) : 0;
            } else {
                detail.markup = null;
            }

            if (detail.salePrice !== null && detail.salePrice > 0) {
                setErrors(prev => ({ ...prev, [index]: false }));
            }

        } else if (field === 'batteryHealth') {
            let numericValue = parseInt(String(value), 10);
            if (isNaN(numericValue)) numericValue = 0;
            if (numericValue < 0) numericValue = 0;
            if (numericValue > 100) numericValue = 100;
            (detail as any)[field] = numericValue;
        } else if (field === 'minimumStock') {
            const numericValue = parseInt(String(value), 10);
            (detail as any)[field] = numericValue > 0 ? numericValue : 1;
        }
        else if (field === 'imei1' || field === 'imei2') {
            const cleaned = value.replace(/\D/g, '').substring(0, 15);
            (detail as any)[field] = cleaned;

            // Auto-jump for 15 chars (standard IMEI) if Continuous Scan is ON
            if (isContinuousScanEnabled && cleaned.length === 15) {
                // Use setTimeout to ensure the state update renders first, although not strictly waiting for it here
                // Logic: update state -> then focus next.
                // Since this function updates state at the end, we can trigger focus immediately if we are sure.
                setTimeout(() => focusNextRow(index, field as string), 50);
            }
        }
        else {
            (detail as any)[field] = value;
        }

        newDetails[index] = detail;
        setDetails(newDetails);
    };

    const inputClassesCompact = "w-full px-2 border rounded-md bg-transparent border-gray-200 focus-within:ring-2 focus-within:ring-primary/10 focus-within:border-primary text-sm transition-all outline-none";


    const handleToggleMinimumStock = (checked: boolean) => {
        setIsMinimumStockEnabled(checked);
        if (!checked) {
            setDetails(prevDetails => prevDetails.map(d => {
                const { minimumStock, ...rest } = d;
                return rest;
            }));
        } else {
            setDetails(prevDetails => prevDetails.map(d => {
                const originalItem = purchaseOrder.items.find(i => i.id === d.purchaseItemId);
                return {
                    ...d,
                    minimumStock: d.isApple ? undefined : (d.minimumStock || originalItem?.minimumStock || 1)
                }
            }));
        }
    };


    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number, field: string) => {
        // Handle Enter or Tab for manual jump or non-15 char inputs (like Serial Numbers)
        if ((e.key === 'Enter' || e.key === 'Tab') && isContinuousScanEnabled) {
            e.preventDefault();
            focusNextRow(index, field);
        }
    };

    const handleLaunchStock = async () => {
        let hasError = false;
        const newDuplicateErrors: Record<number, Partial<Record<'serialNumber' | 'imei1' | 'imei2', boolean>>> = {};

        const isValidImei = (val: string) => !val || /^\d{15}$/.test(val);

        for (let i = 0; i < details.length; i++) {
            const detail = details[i];
            if (detail.imei1 && !isValidImei(detail.imei1)) {
                showToast(`Item #${i + 1}: IMEI 1 deve ter exatamente 15 números.`, 'error');
                return;
            }
            if (detail.imei2 && !isValidImei(detail.imei2)) {
                showToast(`Item #${i + 1}: IMEI 2 deve ter exatamente 15 números.`, 'error');
                return;
            }
        }

        // Global tracking for duplicates within the current batch
        const seenImeis: { [key: string]: number[] } = {};
        const seenSerials: { [key: string]: number[] } = {};

        details.forEach((detail, index) => {
            // Check Serial Number
            const sn = detail.serialNumber?.trim();
            if (sn) {
                if (!seenSerials[sn]) seenSerials[sn] = [];
                seenSerials[sn].push(index);
            }

            // Check IMEI1
            const i1 = detail.imei1?.trim();
            if (i1) {
                if (!seenImeis[i1]) seenImeis[i1] = [];
                seenImeis[i1].push(index);
            }

            // Check IMEI2
            const i2 = detail.imei2?.trim();
            if (i2) {
                if (!seenImeis[i2]) seenImeis[i2] = [];
                seenImeis[i2].push(index);
            }
        });

        // Mark duplicates found in local check
        Object.values(seenSerials).forEach(indices => {
            if (indices.length > 1) {
                hasError = true;
                indices.forEach(idx => {
                    if (!newDuplicateErrors[idx]) newDuplicateErrors[idx] = {};
                    newDuplicateErrors[idx]!.serialNumber = true;
                });
            }
        });

        Object.values(seenImeis).forEach(indices => {
            if (indices.length > 1) {
                hasError = true;
                indices.forEach(idx => {
                    if (!newDuplicateErrors[idx]) newDuplicateErrors[idx] = {};
                    // Determine which field caused the collision for this row
                    const detail = details[idx];
                    if (detail.imei1 && seenImeis[detail.imei1] === indices) newDuplicateErrors[idx]!.imei1 = true;
                    if (detail.imei2 && seenImeis[detail.imei2] === indices) newDuplicateErrors[idx]!.imei2 = true;

                    // Simplified marking: if both exist and collide, mark both to be safe
                    if (detail.imei1 && seenImeis[detail.imei1].length > 1) newDuplicateErrors[idx]!.imei1 = true;
                    if (detail.imei2 && seenImeis[detail.imei2].length > 1) newDuplicateErrors[idx]!.imei2 = true;
                });
            }
        });

        if (hasError) {
            setDuplicateErrors(newDuplicateErrors);
            showToast('Foram encontrados números de série ou IMEIs duplicados nesta lista. Corrija os campos destacados.', 'error');
            return;
        }

        const newPriceErrors: Record<number, boolean> = {};
        let hasPriceError = false;
        for (const [index, detail] of details.entries()) {
            if (detail.salePrice === null || detail.salePrice <= 0) {
                newPriceErrors[index] = true;
                hasPriceError = true;
            }
        }

        setErrors(newPriceErrors);

        if (hasPriceError) {
            showToast('O preço de venda deve ser preenchido e maior que zero.', 'error');
            return;
        }

        setIsSaving(true);
        try {
            const newProducts: (Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'sku'> & { purchaseItemId: string })[] = details.map(d => {
                const originalItem = purchaseOrder.items.find(i => i.id === d.purchaseItemId);
                if (!originalItem) {
                    console.error('[StockInModal] Item mismatch:', d.purchaseItemId, purchaseOrder.items);
                    throw new Error('Erro interno: Item da compra não encontrado durante o processamento.');
                }
                return {
                    brand: originalItem.productDetails.brand,
                    category: originalItem.productDetails.category,
                    model: originalItem.productDetails.model,
                    color: originalItem.productDetails.color,
                    price: d.salePrice!,
                    wholesalePrice: d.wholesalePrice || 0,
                    costPrice: d.costPrice,
                    additionalCostPrice: d.additionalCostPrice,
                    stock: d.quantity,
                    serialNumber: d.serialNumber,
                    imei1: d.imei1,
                    imei2: d.imei2,
                    batteryHealth: d.batteryHealth,
                    condition: d.condition,
                    warranty: d.warranty,
                    storageLocation: d.storageLocation,
                    purchaseItemId: d.purchaseItemId,
                    createdBy: user?.id || null,
                    createdByName: user?.name || 'Sistema',
                    supplierId: purchaseOrder.supplierId,
                    origin: purchaseOrder.isCustomerPurchase ? 'Comprado de Cliente' : 'Compra',
                    minimumStock: (isMinimumStockEnabled && !d.isApple) ? d.minimumStock : undefined,
                    barcodes: d.barcode ? [d.barcode] : [],
                };
            });

            await launchPurchaseToStock(purchaseOrder.id, newProducts, user?.name || 'Usuário');
            showToast(`Estoque da compra #${purchaseOrder.displayId} lançado com sucesso!`, 'success');
            localStorage.removeItem(`stock_launch_draft_${purchaseOrder.id}`);
            onClose(true);
        } catch (error: any) {
            let message = error.message || 'Falha ao lançar estoque.';

            // Check for structured duplicate error from backend
            try {
                const errData = JSON.parse(message);
                if (errData.code === 'DUPLICATE_ENTRIES') {
                    const serverDupErrors: Record<number, Partial<Record<'serialNumber' | 'imei1' | 'imei2', boolean>>> = {};

                    details.forEach((detail, index) => {
                        const { duplicates } = errData;

                        // Check matches against server-reported duplicates
                        if (detail.imei1 && (duplicates.imei1.includes(detail.imei1) || duplicates.imei2.includes(detail.imei1))) {
                            if (!serverDupErrors[index]) serverDupErrors[index] = {};
                            serverDupErrors[index].imei1 = true;
                        }
                        if (detail.imei2 && (duplicates.imei2.includes(detail.imei2) || duplicates.imei1.includes(detail.imei2))) {
                            if (!serverDupErrors[index]) serverDupErrors[index] = {};
                            serverDupErrors[index].imei2 = true;
                        }
                        if (detail.serialNumber && duplicates.serialNumber.includes(detail.serialNumber)) {
                            if (!serverDupErrors[index]) serverDupErrors[index] = {};
                            serverDupErrors[index].serialNumber = true;
                        }
                    });

                    setDuplicateErrors(serverDupErrors);
                    message = 'Existem produtos já cadastrados no sistema com os mesmos IMEIs ou Número de série. Verifique os campos destacados.';
                }
            } catch (e) {
                // Not a JSON error, treat as generic string
            }

            showToast(message, 'error');
            setIsSaving(false);
        }
    };

    const inputClasses = "w-full px-2 border rounded-md bg-white border-gray-200 focus-within:ring-2 focus-within:ring-primary/10 focus-within:border-primary text-sm h-9 transition-all outline-none";

    const renderBulkMode = () => (
        <>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto custom-scrollbar">
                <table className="w-full border-collapse table-fixed min-w-[1000px]">
                    <thead className="text-left text-xs text-muted bg-surface-secondary sticky top-0 z-10">
                        <tr>
                            <th className="p-1 w-[281px] min-w-[281px] font-bold">Descrição</th>
                            <th className="p-1 w-[50px] min-w-[50px] max-w-[50px] font-bold text-center">Qtd</th>
                            <th className="p-1 w-[114px] min-w-[114px] max-w-[114px] font-bold text-center">Condição</th>
                            <th className="p-1 w-[92px] min-w-[92px] max-w-[92px] font-bold text-center">Local</th>
                            <th className="p-1 w-[85px] min-w-[85px] max-w-[85px] font-bold text-center">P. Custo</th>
                            <th className="p-1 w-[95px] min-w-[95px] max-w-[95px] font-bold text-center">Garantia</th>
                            <th className="p-1 w-[45px] min-w-[45px] max-w-[45px] font-bold text-center">MKP%</th>
                            <th className="p-1 w-[91px] min-w-[91px] max-w-[91px] font-bold text-center">Atacado</th>
                            <th className="p-1 w-[91px] min-w-[91px] max-w-[91px] font-bold text-center">Venda</th>
                        </tr>
                    </thead>
                    <tbody>
                        {details.map((detail, index) => (
                            <tr key={index} className="border-b border-border hover:bg-surface-secondary/50">
                                <td className="p-1 align-middle">
                                    <div className="font-bold text-primary line-clamp-2 whitespace-normal text-xs leading-snug" title={detail.itemDescription}>{detail.itemDescription}</div>
                                </td>
                                <td className="p-1 text-center">
                                    <span className="bg-gray-100 px-2 py-1 rounded-md font-bold">{detail.quantity}</span>
                                </td>
                                <td className="p-1">
                                    <select
                                        value={detail.condition}
                                        onChange={(e) => handleDetailChange(index, 'condition', e.target.value)}
                                        className={`${inputClasses} h-9`}
                                    >
                                        {conditionOptions.length === 0 ? <option>Carregando...</option> : <>
                                            {detail.condition && !conditionOptions.some(c => c.name.toLowerCase() === detail.condition?.toLowerCase()) && <option value={detail.condition}>{detail.condition}</option>}
                                            {conditionOptions.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                                        </>}
                                    </select>
                                </td>
                                <td className="p-1">
                                    <select
                                        value={detail.storageLocation}
                                        onChange={(e) => handleDetailChange(index, 'storageLocation', e.target.value)}
                                        className={`${inputClasses} h-9`}
                                    >
                                        {locationOptions.length === 0 ? <option>Carregando...</option> : <>
                                            {detail.storageLocation && !locationOptions.some(l => l.name.toLowerCase() === detail.storageLocation?.toLowerCase()) && <option value={detail.storageLocation}>{detail.storageLocation}</option>}
                                            {locationOptions.map(l => <option key={l.id} value={l.name}>{l.name}</option>)}
                                        </>}
                                    </select>
                                </td>
                                <td className="p-1 font-semibold">{formatCurrency(detail.costPrice + (detail.additionalCostPrice || 0))}</td>
                                <td className="p-1">
                                    <select
                                        value={detail.warranty}
                                        onChange={(e) => handleDetailChange(index, 'warranty', e.target.value)}
                                        className={`${inputClasses} h-9`}
                                    >
                                        {warrantyOptions.length === 0 ? <option>Carregando...</option> : <>
                                            {detail.warranty && !warrantyOptions.some(w => w.name.toLowerCase() === detail.warranty?.toLowerCase()) && <option value={detail.warranty}>{detail.warranty}</option>}
                                            {warrantyOptions.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
                                        </>}
                                    </select>
                                </td>
                                <td className="p-1 w-[45px]">
                                    <div className="relative">
                                        <input
                                            type="number"
                                            step="0.01"
                                            value={detail.markup === null ? '' : detail.markup}
                                            onChange={e => handleDetailChange(index, 'markup', e.target.value)}
                                            className={`${inputClasses} px-1 pr-4 text-center !text-[#16a34a] focus:!text-[#16a34a] font-bold text-[11px]`}
                                        />
                                        <span className="absolute right-1 top-1/2 -translate-y-1/2 !text-[#16a34a] font-bold text-[10px] pointer-events-none">%</span>
                                    </div>
                                </td>
                                <td className="p-1 w-[91px]">
                                    <CurrencyInput
                                        value={detail.wholesalePrice}
                                        onChange={val => handleDetailChange(index, 'wholesalePrice', val)}
                                        className="text-[#ea580c] !rounded-md placeholder:!text-[10px] placeholder:!font-bold placeholder:!uppercase placeholder:!text-gray-400 placeholder:!opacity-100"
                                        placeholder="Opcional"
                                        showPrefix={true}
                                        size="compact"
                                    />
                                </td>
                                <td className="p-1 w-[91px]">
                                    <CurrencyInput
                                        value={detail.salePrice}
                                        onChange={val => handleDetailChange(index, 'salePrice', val)}
                                        className={`${errors[index] ? '!border-danger !ring-1 !ring-danger' : ''} !rounded-md`}
                                        showPrefix={true}
                                        size="compact"
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Mobile Cards */}
            < div className="block md:hidden space-y-3 p-3 bg-gray-50/50" >
                {
                    details.map((detail, index) => (
                        <div key={index} className="bg-white border border-border rounded-md shadow-sm overflow-hidden">
                            <div className="bg-surface-secondary px-4 py-2.5 border-b border-border flex justify-between items-center">
                                <div className="flex items-center gap-2 overflow-hidden">
                                    <span className="bg-primary text-white text-[9px] font-black px-1.5 py-0.5 rounded-md min-w-[24px] text-center">#{index + 1}</span>
                                    <h3 className="font-bold text-primary text-xs truncate">{detail.itemDescription}</h3>
                                </div>
                                <span className="bg-primary/10 text-primary text-[10px] px-2 py-1 rounded-md font-bold whitespace-nowrap">Qtd: {detail.quantity}</span>
                            </div>
                            <div className="p-3 space-y-3">
                                <div className="grid grid-cols-2 gap-2">
                                    <div className="flex flex-col">
                                        <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Condição</label>
                                        <select
                                            value={detail.condition}
                                            onChange={(e) => handleDetailChange(index, 'condition', e.target.value)}
                                            className={`${inputClassesCompact} h-8 py-0`}
                                        >
                                            {conditionOptions.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                                        </select>
                                    </div>
                                    <div className="flex flex-col">
                                        <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Local</label>
                                        <select
                                            value={detail.storageLocation}
                                            onChange={(e) => handleDetailChange(index, 'storageLocation', e.target.value)}
                                            className={`${inputClassesCompact} h-8 py-0`}
                                        >
                                            {locationOptions.map(l => <option key={l.id} value={l.name}>{l.name}</option>)}
                                        </select>
                                    </div>
                                    <div className="flex flex-col">
                                        <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Garantia</label>
                                        <select
                                            value={detail.warranty}
                                            onChange={(e) => handleDetailChange(index, 'warranty', e.target.value)}
                                            className={`${inputClassesCompact} h-8 py-0`}
                                        >
                                            {warrantyOptions.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
                                        </select>
                                    </div>
                                </div>

                                <div className="bg-gray-50/80 p-2 rounded-md border border-border/50">
                                    <div className="flex justify-between items-center mb-1.5 px-1">
                                        <span className="text-[9px] font-bold text-muted uppercase">Custo: {formatCurrency(detail.costPrice + (detail.additionalCostPrice || 0))}</span>
                                        <div className="flex items-center gap-1.5">
                                            <span className="text-[9px] font-bold text-muted">Markup %</span>
                                            <input type="number" step="0.1" value={detail.markup === null ? '' : detail.markup} onChange={e => handleDetailChange(index, 'markup', e.target.value)} className="w-12 h-6 border rounded-md text-[10px] text-center font-bold border-border" />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2">
                                        <div className="grid grid-cols-2 gap-3">
                                            <div className="flex flex-col">
                                                <label className="text-[9px] font-black text-success uppercase ml-1 mb-1">Preço Venda</label>
                                                <CurrencyInput
                                                    value={detail.salePrice}
                                                    onChange={val => handleDetailChange(index, 'salePrice', val)}
                                                    className={errors[index] ? '!border-danger !ring-1 !ring-danger' : ''}
                                                    showPrefix={false}
                                                />
                                            </div>
                                            <div className="flex flex-col">
                                                <label className="text-[9px] font-bold text-orange-600 uppercase ml-1 mb-1">Preço Atacado</label>
                                                <CurrencyInput
                                                    value={detail.wholesalePrice}
                                                    onChange={val => handleDetailChange(index, 'wholesalePrice', val)}
                                                    className="text-orange-600 placeholder:!text-[10px] placeholder:!font-bold placeholder:!uppercase placeholder:!text-gray-400 placeholder:!opacity-100"
                                                    placeholder="Opcional"
                                                    showPrefix={false}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    ))
                }
            </div >
        </>
    );

    const renderUniqueMode = () => {
        const hasAppleItems = details.some(d => d.isApple && d.condition === 'Seminovo');

        return (
            <>
                {/* Desktop Table View */}
                <div className="hidden md:block overflow-x-auto custom-scrollbar">
                    <table className="w-full border-collapse table-fixed min-w-[1200px]">
                        <thead className="text-left text-xs text-gray-900 bg-surface-secondary sticky top-0 z-10">
                            <tr>
                                <th className="p-1 w-[249px] min-w-[249px] font-bold text-left">Descrição</th>
                                <th className="p-1 w-[40px] min-w-[40px] max-w-[40px] font-bold text-center">Qtd</th>
                                <th className="p-1 w-[110px] min-w-[110px] max-w-[110px] font-bold text-center">IMEI 1</th>
                                <th className="p-1 w-[110px] min-w-[110px] max-w-[110px] font-bold text-center">IMEI 2</th>
                                <th className="p-1 w-[150px] min-w-[150px] max-w-[150px] font-bold text-center">Número de série</th>
                                <th className="p-1 w-[95px] min-w-[95px] max-w-[95px] font-bold text-center">Condição</th>
                                <th className="p-1 w-[95px] min-w-[95px] max-w-[95px] font-bold text-center">Garantia</th>
                                {hasAppleItems && <th className="p-1 w-[50px] min-w-[50px] max-w-[50px] font-bold text-center">Bat%</th>}
                                <th className="p-1 w-[92px] min-w-[92px] max-w-[92px] font-bold text-center">Local</th>
                                <th className="p-1 w-[70px] min-w-[70px] max-w-[70px] font-bold text-center">Custo</th>
                                <th className="p-1 w-[45px] min-w-[45px] max-w-[45px] font-bold text-center">MKP%</th>
                                <th className="p-1 w-[91px] min-w-[91px] max-w-[91px] font-bold text-center">Atacado</th>
                                <th className="p-1 w-[91px] min-w-[91px] max-w-[91px] font-bold text-center">Venda</th>
                            </tr>
                        </thead>
                        <tbody>
                            {details.map((detail, index) => (
                                <tr key={index} className={`border-b border-border hover:bg-surface-secondary/50 ${!detail.hasImei ? 'bg-blue-50/30' : ''}`}>
                                    <td className="p-1 align-middle">
                                        <div className="font-bold text-primary line-clamp-2 whitespace-normal text-xs leading-snug" title={detail.itemDescription}>{detail.itemDescription}</div>
                                    </td>
                                    <td className="p-1 text-center">
                                        <span className={`px-2 py-1 rounded-md font-bold text-sm ${detail.hasImei ? 'bg-gray-100 text-gray-500' : 'bg-success/20 text-success'}`}>
                                            {detail.quantity}
                                        </span>
                                    </td>
                                    <td className="p-1">
                                        {detail.hasImei ? (
                                            <input
                                                id={`stock-input-${index}-imei1`}
                                                type="text"
                                                value={detail.imei1}
                                                onChange={e => handleDetailChange(index, 'imei1', e.target.value)}
                                                onKeyDown={e => handleKeyDown(e, index, 'imei1')}
                                                className={`${inputClasses} h-9 w-full text-sm ${duplicateErrors[index]?.imei1 ? 'border-danger bg-red-50 ring-1 ring-danger' : ''} ${isContinuousScanEnabled ? 'focus:ring-2 focus:ring-yellow-500 font-mono transition-colors' : ''}`}
                                                placeholder={isContinuousScanEnabled ? "Bipe..." : ""}
                                            />
                                        ) : (
                                            <span className="text-muted text-center block">-</span>
                                        )}
                                    </td>
                                    <td className="p-1">
                                        {detail.hasImei ? (
                                            <input
                                                id={`stock-input-${index}-imei2`}
                                                type="text"
                                                value={detail.imei2}
                                                onChange={e => handleDetailChange(index, 'imei2', e.target.value)}
                                                onKeyDown={e => handleKeyDown(e, index, 'imei2')}
                                                className={`${inputClasses} h-9 w-full text-sm ${duplicateErrors[index]?.imei2 ? 'border-danger bg-red-50 ring-1 ring-danger' : ''} ${isContinuousScanEnabled ? 'focus:ring-2 focus:ring-yellow-500 font-mono transition-colors' : ''}`}
                                            />
                                        ) : (
                                            <span className="text-muted text-center block">-</span>
                                        )}
                                    </td>
                                    <td className="p-1">
                                        {detail.hasImei ? (
                                            <input
                                                id={`stock-input-${index}-serialNumber`}
                                                type="text"
                                                value={detail.serialNumber}
                                                onChange={e => handleDetailChange(index, 'serialNumber', e.target.value)}
                                                onKeyDown={e => handleKeyDown(e, index, 'serialNumber')}
                                                className={`${inputClasses} h-9 w-full text-sm ${duplicateErrors[index]?.serialNumber ? 'border-danger bg-red-50 ring-1 ring-danger' : ''} ${isContinuousScanEnabled ? 'focus:ring-2 focus:ring-yellow-500 font-mono transition-colors' : ''}`}
                                            />
                                        ) : (
                                            <span className="text-muted text-center block">-</span>
                                        )}
                                    </td>
                                    <td className="p-1">
                                        <select value={detail.condition} onChange={e => handleDetailChange(index, 'condition', e.target.value)} className={`${inputClasses} h-9`}>
                                            {conditionOptions.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                                        </select>
                                    </td>
                                    <td className="p-1">
                                        <select value={detail.warranty} onChange={e => handleDetailChange(index, 'warranty', e.target.value)} className={`${inputClasses} h-9`}>
                                            {warrantyOptions.length === 0 ? <option>Carregando...</option> : <>
                                                {detail.warranty && !warrantyOptions.some(w => w.name.toLowerCase() === detail.warranty?.toLowerCase()) && <option value={detail.warranty}>{detail.warranty}</option>}
                                                {warrantyOptions.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
                                            </>}
                                        </select>
                                    </td>
                                    {hasAppleItems && (
                                        <td className="p-1 text-center">
                                            {detail.isApple && detail.condition === 'Seminovo' ? (
                                                <input type="number" value={detail.batteryHealth} onChange={e => handleDetailChange(index, 'batteryHealth', e.target.value)} className={`${inputClasses} h-9 w-full text-center`} />
                                            ) : (
                                                <span className="text-muted text-center block">-</span>
                                            )}
                                        </td>
                                    )}
                                    <td className="p-1">
                                        <select value={detail.storageLocation} onChange={e => handleDetailChange(index, 'storageLocation', e.target.value)} className={`${inputClasses} h-9`}>
                                            {locationOptions.map(l => <option key={l.id} value={l.name}>{l.name}</option>)}
                                        </select>
                                    </td>
                                    <td className="p-1 font-semibold text-[12px]">{formatCurrency(detail.costPrice + (detail.additionalCostPrice || 0))}</td>
                                    <td className="p-1 text-center w-[45px]">
                                        <div className="relative">
                                            <input
                                                type="number"
                                                step="1"
                                                value={detail.markup === null ? '' : detail.markup}
                                                onChange={e => handleDetailChange(index, 'markup', e.target.value)}
                                                className={`${inputClasses} h-9 w-full px-1 pr-4 text-center !text-[#16a34a] focus:!text-[#16a34a] font-bold text-[11px]`}
                                            />
                                            <span className="absolute right-1 top-1/2 -translate-y-1/2 !text-[#16a34a] font-bold text-[10px] pointer-events-none">%</span>
                                        </div>
                                    </td>
                                    <td className="p-1"><CurrencyInput value={detail.wholesalePrice} onChange={val => handleDetailChange(index, 'wholesalePrice', val)} className="text-[#ea580c] !rounded-md placeholder:!text-[10px] placeholder:!font-bold placeholder:!uppercase placeholder:!text-gray-400 placeholder:!opacity-100" placeholder="Opcional" showPrefix={true} size="compact" /></td>
                                    <td className="p-1"><CurrencyInput value={detail.salePrice} onChange={val => handleDetailChange(index, 'salePrice', val)} className={`${errors[index] ? '!border-danger !ring-1 !ring-danger' : ''} !rounded-md`} showPrefix={true} size="compact" /></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div >

                {/* Mobile Cards View */}
                < div className="block md:hidden space-y-3 p-3 bg-gray-50/50" >
                    {
                        details.map((detail, index) => (
                            <div key={index} className={`bg-surface border border-border rounded-md shadow-sm overflow-hidden animate-fade-in ${!detail.hasImei ? 'border-l-4 border-l-success' : ''}`} style={{ animationDelay: `${index * 30}ms` }}>
                                {/* Compact Header */}
                                <div className="bg-surface-secondary px-4 py-2.5 border-b border-border flex justify-between items-center">
                                    <div className="flex items-center gap-2 overflow-hidden">
                                        <span className="bg-primary text-white text-[9px] font-black px-1.5 py-0.5 rounded-md min-w-[24px] text-center">#{index + 1}</span>
                                        <h3 className="font-bold text-primary text-xs truncate">{detail.itemDescription}</h3>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${detail.hasImei ? 'bg-gray-100 text-gray-500' : 'bg-success/20 text-success'}`}>
                                            Qtd: {detail.quantity}
                                        </span>
                                    </div>
                                </div>

                                <div className="p-3 space-y-3">
                                    {/* Dense Identification Row - Só mostra se hasImei */}
                                    {detail.hasImei && (
                                        <div className="space-y-2">
                                            <div className="relative group">
                                                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-muted uppercase z-10 pointer-events-none group-focus-within:text-success transition-colors">IMEI 1</span>
                                                <input
                                                    id={`stock-input-${index}-imei1`}
                                                    type="text"
                                                    value={detail.imei1}
                                                    onChange={e => handleDetailChange(index, 'imei1', e.target.value)}
                                                    onKeyDown={e => handleKeyDown(e, index, 'imei1')}
                                                    className={`${inputClassesCompact} pl-14 h-9 text-sm font-semibold rounded-md ${duplicateErrors[index]?.imei1 ? 'border-danger bg-red-50 ring-1 ring-danger' : ''} ${isContinuousScanEnabled ? 'focus:ring-2 focus:ring-yellow-500 font-mono transition-colors' : ''}`}
                                                />
                                            </div>
                                            <div className="grid grid-cols-2 gap-2">
                                                <div className="relative group">
                                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-muted uppercase z-10 pointer-events-none group-focus-within:text-success transition-colors">IMEI 2</span>
                                                    <input
                                                        id={`stock-input-${index}-imei2`}
                                                        type="text"
                                                        value={detail.imei2}
                                                        onChange={e => handleDetailChange(index, 'imei2', e.target.value)}
                                                        onKeyDown={e => handleKeyDown(e, index, 'imei2')}
                                                        className={`${inputClassesCompact} pl-14 h-9 text-[11px] rounded-md ${duplicateErrors[index]?.imei2 ? 'border-danger bg-red-50 ring-1 ring-danger' : ''} ${isContinuousScanEnabled ? 'focus:ring-2 focus:ring-yellow-500 font-mono transition-colors' : ''}`}
                                                    />
                                                </div>
                                                <div className="relative group">
                                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-muted uppercase z-10 pointer-events-none group-focus-within:text-success transition-colors">Número de série</span>
                                                    <input
                                                        id={`stock-input-${index}-serialNumber`}
                                                        type="text"
                                                        value={detail.serialNumber}
                                                        onChange={e => handleDetailChange(index, 'serialNumber', e.target.value)}
                                                        onKeyDown={e => handleKeyDown(e, index, 'serialNumber')}
                                                        className={`${inputClassesCompact} pl-10 h-9 text-[11px] rounded-md ${duplicateErrors[index]?.serialNumber ? 'border-danger bg-red-50 ring-1 ring-danger' : ''} ${isContinuousScanEnabled ? 'focus:ring-2 focus:ring-yellow-500 font-mono transition-colors' : ''}`}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Compact Specs Row */}
                                    <div className="grid grid-cols-2 gap-2">
                                        <div className="flex flex-col">
                                            <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Condição</label>
                                            <select value={detail.condition} onChange={e => handleDetailChange(index, 'condition', e.target.value)} className={`${inputClassesCompact} h-9 py-0 rounded-md`}>
                                                {conditionOptions.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                                            </select>
                                        </div>
                                        <div className="flex flex-col">
                                            <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Local</label>
                                            <select value={detail.storageLocation} onChange={e => handleDetailChange(index, 'storageLocation', e.target.value)} className={`${inputClassesCompact} h-9 py-0 rounded-md`}>
                                                {locationOptions.map(l => <option key={l.id} value={l.name}>{l.name}</option>)}
                                            </select>
                                        </div>
                                        <div className="flex flex-col">
                                            <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Garantia</label>
                                            <select value={detail.warranty} onChange={e => handleDetailChange(index, 'warranty', e.target.value)} className={`${inputClassesCompact} h-9 py-0 rounded-md`}>
                                                {warrantyOptions.map(w => <option key={w.id} value={w.name}>{w.name}</option>)}
                                            </select>
                                        </div>
                                        {detail.isApple && detail.condition === 'Seminovo' && (
                                            <div className="flex flex-col">
                                                <label className="text-[9px] font-bold text-muted uppercase mb-0.5">Saúde Bateria</label>
                                                <div className="relative">
                                                    <input type="number" value={detail.batteryHealth} onChange={e => handleDetailChange(index, 'batteryHealth', e.target.value)} className={`${inputClassesCompact} h-9 text-center font-bold text-blue-600 pr-5 rounded-md`} />
                                                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted">%</span>
                                                </div>
                                            </div>
                                        )}

                                    </div>

                                    {/* Compact Pricing Row */}
                                    <div className="bg-gray-50/80 p-2 rounded-md border border-border/50">
                                        <div className="flex justify-between items-center mb-1.5 px-1">
                                            <span className="text-[9px] font-bold text-muted uppercase">Custo: {formatCurrency(detail.costPrice + (detail.additionalCostPrice || 0))}</span>
                                            <div className="flex items-center gap-1.5">
                                                <span className="text-[9px] font-bold text-muted">Markup %</span>
                                                <input type="number" step="0.1" value={detail.markup === null ? '' : detail.markup} onChange={e => handleDetailChange(index, 'markup', e.target.value)} className="w-12 h-6 border rounded-md text-[10px] text-center font-bold border-border" />
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-3">
                                            <div className="flex flex-col">
                                                <label className="text-[9px] font-black text-success uppercase ml-1 mb-1">Preço Venda</label>
                                                <CurrencyInput
                                                    value={detail.salePrice}
                                                    onChange={val => handleDetailChange(index, 'salePrice', val)}
                                                    className={errors[index] ? '!border-danger !ring-1 !ring-danger' : ''}
                                                    showPrefix={false}
                                                />
                                            </div>
                                            <div className="flex flex-col">
                                                <label className="text-[9px] font-bold text-orange-600 uppercase ml-1 mb-1">Preço Atacado</label>
                                                <CurrencyInput
                                                    value={detail.wholesalePrice}
                                                    onChange={val => handleDetailChange(index, 'wholesalePrice', val)}
                                                    className="text-orange-600 placeholder:!text-[10px] placeholder:!font-bold placeholder:!uppercase placeholder:!text-gray-400 placeholder:!opacity-100"
                                                    placeholder="Opcional"
                                                    showPrefix={false}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    }
                </div >
            </>
        );
    };

    return createPortal(
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-end md:items-center z-[99999] p-0 md:p-4 animate-fade-in">
            <div className="bg-surface w-full max-w-[99vw] h-[100dvh] md:h-auto md:max-h-[95vh] md:rounded-md shadow-2xl flex flex-col overflow-hidden">
                <div className="flex justify-between items-center p-4 md:p-6 border-b border-border bg-surface sticky top-0 z-20 gap-4">
                    <div>
                        <h2 className="text-lg md:text-2xl font-black text-primary leading-tight">Lançar Compra #{purchaseOrder.displayId}</h2>
                        <p className="text-xs md:text-sm text-muted font-medium">Fornecedor: <span className="text-primary">{purchaseOrder.supplierName}</span></p>
                    </div>

                    {/* Quick Stock Search */}
                    <div className="relative flex-1 max-w-md mx-4 hidden md:block">
                        <button
                            type="button"
                            onClick={() => setShowSearchModal(true)}
                            className="relative w-fit rounded-full bg-[#f8fafc] border-[1.5px] border-slate-200 flex items-center px-5 py-2 hover:bg-slate-100 hover:border-slate-300 transition-all overflow-hidden h-11 shadow-sm group cursor-pointer"
                        >
                            <ArchiveBoxIcon className="h-5 w-5 text-[#334155] shrink-0 group-hover:text-primary transition-colors" strokeWidth={2.5} />
                            <span className="text-[13px] font-black text-[#334155] group-hover:text-[#1e293b] uppercase ml-3 tracking-wide">
                                BUSCA RÁPIDA ESTOQUE
                            </span>
                        </button>
                    </div>

                    <button onClick={() => onClose(false)} className="p-2 text-muted hover:text-danger hover:bg-danger/10 rounded-md transition-colors">
                        <XCircleIcon className="h-7 w-7 md:h-8 md:w-8" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar bg-gray-50/30">
                    {isBulkMode ? renderBulkMode() : renderUniqueMode()}
                </div>

                <div className="p-4 md:p-6 border-t border-border bg-surface mt-auto shadow-[0_-4px_20px_rgba(0,0,0,0.05)] flex items-center justify-between">

                    <button
                        onClick={() => setIsContinuousScanEnabled(!isContinuousScanEnabled)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-md font-bold text-sm transition-all ${isContinuousScanEnabled ? 'bg-yellow-100 text-yellow-700 ring-2 ring-yellow-500' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                    >
                        <BoltIcon className={`h-5 w-5 ${isContinuousScanEnabled ? 'animate-pulse' : ''}`} />
                        {isContinuousScanEnabled ? 'Leitura Contínua ATIVA' : 'Leitura Contínua'}
                    </button>

                    <div className="flex gap-4">
                        <button
                            onClick={handleLaunchStock}
                            disabled={isSaving}
                            className="w-full md:w-auto md:ml-auto px-8 py-3 bg-success text-white rounded-md hover/bg-success/90 font-bold disabled:bg-muted flex items-center justify-center gap-3 text-lg shadow-lg shadow-success/20 transition-all active:scale-95 mb-safe"
                        >
                            {isSaving ? <SpinnerIcon className="h-6 w-6 animate-spin" /> : <DocumentArrowUpIcon className="h-6 w-6" />}
                            Lançar no Estoque
                        </button>
                    </div>
                </div>
            </div>

            {showSearchModal && (
                <StockSearchModal
                    products={allProducts}
                    onClose={() => setShowSearchModal(false)}
                />
            )}
        </div>,
        document.body
    );
};

export default StockInModal;
