import React from 'react';

interface ChatBadgeProps {
    count: number;
    onClick: () => void;
    isOpen?: boolean;
    className?: string;
}

const ChatBadge: React.FC<ChatBadgeProps> = ({ count, onClick, isOpen, className = '' }) => {
    return (
        <button
            onClick={onClick}
            title="Chat Interno"
            aria-label={`Chat Interno${count > 0 ? ` - ${count} nova${count !== 1 ? 's' : ''} mensagem${count !== 1 ? 'ns' : ''}` : ''}`}
            className={`relative text-muted hover:text-primary transition-all duration-200 ${isOpen ? 'text-violet-600' : ''} ${className}`}
        >
            {/* Ícone de chat */}
            <svg
                className={`h-6 w-6 transition-transform duration-200 ${isOpen ? 'scale-110' : ''}`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
            >
                <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155"
                />
            </svg>

            {/* Badge de não lidas */}
            {count > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white shadow-sm animate-bounce-once">
                    {count > 99 ? '99+' : count}
                </span>
            )}

            {/* Indicador de "aberto" */}
            {isOpen && count === 0 && (
                <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5 rounded-full bg-violet-500 border-2 border-white" />
            )}
        </button>
    );
};

export default ChatBadge;
