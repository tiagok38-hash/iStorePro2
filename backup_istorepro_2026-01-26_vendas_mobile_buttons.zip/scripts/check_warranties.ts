import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function checkWarranties() {
    console.log("Checking columns for 'warranties'...");
    const { data, error } = await supabase.from('warranties').select('*').limit(1);
    if (error) { console.error(error); return; }
    if (data && data.length > 0) {
        console.log("Columns:", Object.keys(data[0]));
    } else {
        console.log("Table empty or missing.");
    }
}

checkWarranties();
