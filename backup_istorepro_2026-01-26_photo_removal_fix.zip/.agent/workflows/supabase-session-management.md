---
description: Garantir sessão Supabase funcional com revalidação automática
---

# Workflow: Supabase Session Management

Este documento descreve como o sistema de gerenciamento de sessão Supabase foi implementado no iStore.

## 1. CONFIGURAÇÃO DO SUPABASE (supabaseClient.ts)

O cliente Supabase está configurado com:
- ✅ `persistSession: true` - Sessão persistida no localStorage
- ✅ `autoRefreshToken: true` - Token renovado automaticamente
- ✅ `detectSessionInUrl: true` - Detecta sessão via URL (OAuth)
- ✅ `storageKey: 'istore-auth'` - Chave customizada para storage

## 2. GLOBAL STATES (UserContext.tsx)

Estados globais disponíveis:
- `loading` (boolean) - Estado de carregamento
- `session` (object | null) - Sessão Supabase atual
- `user` (object | null) - Dados do usuário logado
- `permissions` (object | null) - Permissões do usuário
- `isOnline` (boolean) - Status de conexão
- `isAuthenticated` (boolean) - Se usuário está autenticado

## 3. WORKFLOW: CheckSession (UserContext.tsx)

Função: `checkSession()`

Executado automaticamente quando:
- App carrega (On Page Load)
- Usuário volta para a aba (visibilitychange → visible)
- Janela ganha foco (window focus)
- Conexão é restaurada (online event)

Fluxo:
1. Verifica se está online
2. Busca sessão do Supabase: `supabase.auth.getSession()`
3. **SE sessão válida:**
   - Atualiza `session`, `user`, `permissions`
   - Dispara evento `app-focus-refetch` para recarregar dados
4. **SE sessão inválida:**
   - Limpa estado: `session = null`, `user = null`
   - ProtectedRoute redireciona para `/login`

## 4. WORKFLOW: LoadInitialData

Evento `app-focus-refetch` dispara recarregamento de dados em todas as páginas que escutam este evento.

Páginas implementadas:
- Dashboard.tsx ✅
- Vendas.tsx ✅  
- Products.tsx ✅
- Customers.tsx ✅

Cada página tem:
```javascript
useEffect(() => {
    fetchData();
    
    const handleRefetch = () => {
        console.log('Page: Refetching data due to app focus/online event');
        fetchData();
    };
    
    window.addEventListener('app-focus-refetch', handleRefetch);
    
    return () => {
        window.removeEventListener('app-focus-refetch', handleRefetch);
    };
}, [fetchData]);
```

## 5. KEEP ALIVE TIMER (3 minutos)

Implementado no UserContext.tsx:
- Intervalo: 180000ms (3 minutos)
- Condição: Executa apenas se `session` existe
- Ação: `supabase.rpc('now')` ou query simples
- Se falhar: Chama `checkSession()` para revalidar

## 6. EVENTOS DE APLICAÇÃO

Listeners configurados no UserContext:

| Evento | Handler | Ação |
|--------|---------|------|
| `visibilitychange (visible)` | handleVisibilityChange | → checkSession() |
| `window focus` | handleWindowFocus | → checkSession() |
| `online` | handleOnline | → setIsOnline(true) + checkSession() |
| `offline` | handleOffline | → setIsOnline(false) |

## 7. ON PAGE LOAD (Páginas Protegidas)

ProtectedRoute.tsx garante:
- Se `loading == true`: Mostra spinner
- Se `isAuthenticated == false`: Redireciona para `/login`
- Se sem permissão: Redireciona para primeira página permitida

## 8. CONTROLE DE INTERFACE

Componentes disponíveis em `GlobalLoading.tsx`:

### GlobalLoadingOverlay
```tsx
<GlobalLoadingOverlay show={loading} />
```
- Overlay fullscreen com spinner premium
- Mostra status online/offline

### OnlineStatusIndicator
```tsx
<OnlineStatusIndicator />
```
- Badge no canto inferior esquerdo
- Aparece quando offline ou quando conexão é restaurada

### PageLoadingWrapper
```tsx
<PageLoadingWrapper loading={loading}>
  {/* conteúdo da página */}
</PageLoadingWrapper>
```
- Wrapper para páginas que carregam dados

### SkeletonCard / SkeletonTable
```tsx
<SkeletonCard />
<SkeletonTable rows={5} />
```
- Placeholders animados para loading

### useSessionRefresh Hook
```tsx
const { checkSession } = useSessionRefresh(() => {
  fetchData();
});
```
- Hook para páginas que precisam reagir a revalidação

## 9. TESTE FINAL

Para testar o fluxo completo:

1. Abrir aplicação → Login aparece
2. Fazer login → Dashboard carrega
3. Trocar de aba por 5-10 minutos
4. Voltar para a aplicação
5. **Resultado esperado:**
   - Loading breve aparece (se necessário)
   - Sessão é validada (ver console)
   - Dados recarregam automaticamente
   - Nenhuma tela branca

## Estrutura de Arquivos

```
contexts/
├── UserContext.tsx     # Estado global de auth + checkSession + keepAlive
├── AppContext.tsx      # (Opcional) Contexto adicional se necessário
├── ToastContext.tsx    # Notificações
└── ThemeContext.tsx    # Tema

components/
├── GlobalLoading.tsx   # Componentes de loading
├── ProtectedRoute.tsx  # Proteção de rotas
└── ...

supabaseClient.ts       # Cliente Supabase configurado
```
