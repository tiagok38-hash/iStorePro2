
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function investigateSaleV4() {
    console.log('Searching for customer Maria...');

    // Find Customer
    const { data: customers } = await supabase
        .from('customers')
        .select('*')
        .ilike('name', '%Maria Jesuina%');

    if (!customers || customers.length === 0) {
        console.log('Customer not found.');
        return;
    }

    const customer = customers[0];
    console.log(`Found Customer: ${customer.name} (ID: ${customer.id})`);

    // Find Sales for this customer
    console.log(`Fetching sales for customer ${customer.id}...`);
    const { data: sales, error } = await supabase
        .from('sales')
        .select('*')
        .eq('customerId', customer.id); // Assuming camelCase per previous findings

    if (error) {
        console.error('Error fetching sales:', error);
        // Try snake_case if camel fails
        const { data: sales2, error: error2 } = await supabase
            .from('sales')
            .select('*')
            .eq('customer_id', customer.id);

        if (error2) console.error('Error fetching sales (snake_case):', error2);
        else analyzeSales(sales2);
        return;
    }

    analyzeSales(sales);
}

async function analyzeSales(sales: any[]) {
    if (!sales || sales.length === 0) {
        console.log('No sales found for this customer.');
        return;
    }

    for (const sale of sales) {
        console.log('--------------------------------------------------');
        console.log(`Sale ID: ${sale.id}`);
        console.log(`Date: ${sale.date}`);
        console.log(`Total: ${sale.total}`);
        // console.log(`Items:`, JSON.stringify(sale.items, null, 2));

        if (sale.items && sale.items.length > 0) {
            for (const item of sale.items) {
                const productId = item.productId;
                console.log(`  Fetching product ${productId}...`);
                const { data: product } = await supabase
                    .from('products')
                    .select('*')
                    .eq('id', productId)
                    .single();

                if (product) {
                    console.log(`  Product: ${product.model}`);
                    console.log(`  Cost Price: ${product.costPrice}`);
                    console.log(`  Additional Cost: ${product.additionalCostPrice}`);
                    const cost = (product.costPrice || 0) + (product.additionalCostPrice || 0);
                    const profit = item.unitPrice - cost;
                    console.log(`  Calculated Profit for item: ${profit} (Sale: ${item.unitPrice} - Cost: ${cost})`);
                }
            }
        }
    }
}

investigateSaleV4();
