import { createClient } from '@supabase/supabase-js';

// Hardcoding for the script
const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function checkColumns() {
    console.log("--- Checking Table Columns ---");

    // We try to insert a dummy record with the new columns to see if it complains about "column does not exist"
    // actually, listing columns via information_schema is better if we had permissions, but we might not.
    // Let's try to select the specific columns from the table.

    const { data, error } = await supabase
        .from('customers')
        .select('id, avatar_url, street, is_blocked')
        .limit(1);

    if (error) {
        console.error("[❌] Failed to select new columns from 'customers'.");
        console.error(`    Error: ${error.message}`);
        if (error.code === 'PGRST301' || error.message.includes('does not exist')) {
            console.log("    -> DIAGNOSIS: The columns definitely DO NOT exist or are not exposed.");
        }
    } else {
        console.log("[✅] Success! The columns 'avatar_url', 'street', etc. EXIST in 'customers'.");
        console.log("    -> If you still see errors in the app, try restarting the 'npm run dev' process.");
    }

    // Check Suppliers
    const { data: sData, error: sError } = await supabase
        .from('suppliers')
        .select('id, avatar_url, contact_person, linked_customer_id')
        .limit(1);

    if (sError) {
        console.error("[❌] Failed to select new columns from 'suppliers'.");
        console.error(`    Error: ${sError.message}`);
    } else {
        console.log("[✅] Success! The columns EXIST in 'suppliers'.");
    }

}

checkColumns();
