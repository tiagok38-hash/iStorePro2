import { createClient } from '@supabase/supabase-js';

// Hardcoding for the script to avoid import issues relative to project root
const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const tables = [
    'users',
    'products',
    'sales',
    'customers',
    'suppliers',
    'permissions_profiles',
    'audit_logs',
    'cash_sessions',
    'receipt_terms',
    'brands',
    'categories'
];

async function check() {
    console.log("--- Supabase Diagnostic Tool ---");
    console.log(`Target URL: ${SUPABASE_URL}`);

    let allGood = true;

    for (const table of tables) {
        try {
            // We use select with count to verify access and existence without fetching heavy data
            const { count, error } = await supabase.from(table).select('*', { count: 'exact', head: true });

            if (error) {
                allGood = false;
                console.error(`[❌] Table '${table}': FAILED`);
                console.error(`    Error Code: ${error.code}`);
                console.error(`    Message: ${error.message}`);

                if (error.code === '42P01') {
                    console.error(`    -> DIAGNOSIS: The table '${table}' DOES NOT EXIST in the database.`);
                } else if (error.code === '42501') {
                    console.error(`    -> DIAGNOSIS: RLS Policy mismatch. You (Anon) permission denied.`);
                }
            } else {
                console.log(`[✅] Table '${table}': OK (Records: ${count})`);
            }
        } catch (e: any) {
            allGood = false;
            console.error(`[❌] Table '${table}': CRITICAL ERROR`);
            console.error(e);
        }
    }

    console.log("\n--- Connection Test ---");
    try {
        const { data, error } = await supabase.from('users').select('count').limit(1);
        if (error) {
            console.log("Connection check: Failed to query 'users'.");
        } else {
            console.log("Connection check: Success. API is reachable.");
        }
    } catch (e) {
        console.log("Connection check: Network error or bad URL.");
    }

    console.log("\n--- Summary ---");
    if (allGood) {
        console.log("All checked tables exist and are accessible.");
    } else {
        console.log("Some tables are missing or inaccessible. Please run the setup SQL script.");
    }
}

check();
