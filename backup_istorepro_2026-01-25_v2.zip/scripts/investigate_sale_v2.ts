
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function investigateRecentSales() {
    console.log('Fetching recent sales...');

    // Fetch last 20 sales
    const { data: sales, error } = await supabase
        .from('sales')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

    if (error) {
        console.error('Error fetching sales:', error);
        return;
    }

    if (!sales) { console.log("No sales."); return; }

    const targetCustomer = 'Maria Jesuina';

    for (const sale of sales) {
        if (sale.customerName && sale.customerName.includes('Maria')) {
            console.log('--------------------------------------------------');
            console.log(`Sale ID: ${sale.id}`);
            console.log(`Date: ${sale.date}`);
            console.log(`Customer: ${sale.customerName}`);
            console.log(`Total: ${sale.total}`);
            console.log(`Items:`, JSON.stringify(sale.items, null, 2));

            if (sale.items && sale.items.length > 0) {
                for (const item of sale.items) {
                    const productId = item.productId;
                    const { data: product } = await supabase
                        .from('products')
                        .select('*')
                        .eq('id', productId)
                        .single();

                    if (product) {
                        console.log(`  Product: ${product.model}`);
                        console.log(`  Cost Price: ${product.costPrice}`);
                        console.log(`  Additional Cost: ${product.additionalCostPrice}`);
                        const cost = (product.costPrice || 0) + (product.additionalCostPrice || 0);
                        const profit = item.unitPrice - cost;
                        console.log(`  Calculated Profit for item: ${profit}`);
                    }
                }
            }
        }
    }
}

investigateRecentSales();
