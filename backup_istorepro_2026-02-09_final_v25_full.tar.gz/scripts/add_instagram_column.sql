-- Script para adicionar a coluna instagram à tabela company_info
-- Execute este script no SQL Editor do Supabase

-- Adicionar coluna instagram
ALTER TABLE company_info
ADD COLUMN IF NOT EXISTS instagram TEXT;

-- Verificar se a coluna foi criada
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'company_info';
