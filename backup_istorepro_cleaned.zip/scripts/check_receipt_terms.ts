import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bgwfyumunybbdthgykoh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_5gPLseUzMLc6U2kyxyzg7g_gcY7edNS';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function checkColumns() {
    console.log("Checking columns for 'receipt_terms'...");
    // We can use a trick to see columns by selecting one row and looking at keys
    const { data, error } = await supabase.from('receipt_terms').select('*').limit(1);

    if (error) {
        console.error("Error fetching receipt_terms:", error);
        return;
    }

    if (data && data.length > 0) {
        console.log("Found row. Columns:", Object.keys(data[0]));
        console.log("Data sample:", JSON.stringify(data[0], null, 2));
    } else {
        console.log("No rows found in receipt_terms. Checking table existence...");
        const { error: existenceError } = await supabase.from('receipt_terms').select('count').limit(1);
        if (existenceError) {
            console.error("Table 'receipt_terms' seems missing or inaccessible:", existenceError);
        } else {
            console.log("Table exists but it is empty.");
        }
    }
}

checkColumns();
