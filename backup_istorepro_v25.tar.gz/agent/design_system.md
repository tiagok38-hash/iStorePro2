# iStorePro Design System

This document defines the core design principles and styling tokens for iStorePro. All new components and pages MUST follow these guidelines to maintain a consistent "Premium SaaS" aesthetic.

## 1. Core Principles
- **Aesthetic**: Premium SaaS, Minimalist, Elegant.
- **Surface**: Use Glassmorphism (blur + opacity) for overlays and headers.
- **Corners**: Highly rounded (`xl` for elements, `3xl` for containers).
- **Feedback**: Subtle micro-animations (pulse, active scales, hover transforms).

## 2. Color Palette
Defined in `index.html` via CSS variables.

| Token | CSS Variable | Hex (Approx) | Usage |
| :--- | :--- | :--- | :--- |
| **Background** | `--color-background` | `#F6F5FB` | Body background |
| **Surface** | `--color-surface` | `#FFFFFF` | Cards, Modals (usually with 0.7-0.9 opacity) |
| **Primary Text** | `--color-primary` | `#2A2A2E` | Main headings and labels |
| **Secondary Text** | `--color-secondary` | `#6B6B7A` | Metadata and secondary descriptions |
| **Accent** | `--color-accent` | `#7B61FF` | Action highlights, active states |
| **Success** | `--color-success` | `#22C55E` | Finalized sales, stock add, active statuses |
| **Danger** | `--color-danger` | `#FF6B6B` | Deletion, cancellation, errors |

## 3. Typography
- **Primary Font**: `Outfit` (loaded via Google Fonts).
- **Headings**: `font-bold` or `font-black`.
- **Interactions**: Buttons use `font-bold` and often `uppercase` with `tracking-widest`.

## 4. Components & Utilities

### Glassmorphism
- **`.glass-card`**: Base for main containers.
  ```css
  background: rgba(255, 255, 255, 0.75);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.35);
  border-radius: 24px;
  ```
- **`.backdrop-blur-sm`**: Used for modal overlays (`bg-black/50`).

### Buttons
- **Standard Button**: `h-12`, `px-8`, `rounded-xl`, `font-bold`, `uppercase`, `text-xs/sm`.
- **Primary Action (Dark)**: `bg-gray-800 hover:bg-gray-700 text-white shadow-sm`.
- **Success Action**: `bg-success hover:bg-success-dark text-white shadow-lg`.
- **Danger Action**: `bg-red-100 text-red-600 hover:bg-red-200`.

### Modals & Forms
- **Modals**: Fixed, centered, `z-index` >= 50. Container is `rounded-3xl` (24px).
- **Inputs**: `rounded-xl` (16px), `h-12`, `border-gray-300`. Focused borders use `--color-accent` or `--color-success`.
- **Selects**: Standardized arrow via `index.html` CSS override.

### Scrollbar
- Always use `.custom-scrollbar` for internal scroll areas.
- Width: `6px`. Thumb color: `rgba(123, 97, 255, 0.2)`.

## 5. Spacing
- **Grids**: Use `gap-4` or `gap-6`.
- **Page Padding**: `px-4 md:px-6`.
- **Section Margin**: `space-y-4` or `space-y-6`.

---
*Note: This system relies on Tailwind CSS for 99% of implementations. Always check index.html for global overrides.*
