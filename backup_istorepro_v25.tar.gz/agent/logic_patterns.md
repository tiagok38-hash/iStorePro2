# iStorePro Logic Patterns

This document describes the architectural and business logic rules of iStorePro. All new features must maintain these patterns to ensure system integrity.

## 1. Data Layer & Naming Conventions
- **Naming Divergence**: 
    - **Database (Supabase)**: Uses `snake_case` (ex: `cash_session_id`, `created_at`).
    - **Frontend (React/Types)**: Uses `camelCase` (ex: `cashSessionId`, `createdAt`).
- **Mapping**: The `mockApi.ts` service layer is responsible for translating between these two formats when fetching or sending data.
- **Cache**: Most GET operations in `mockApi` use a 5-minute cache (`fetchWithCache`). Use `clearCache(['key'])` after mutations.

## 2. Product Lifecycle & Stock
- **Unique Identification**: Products are primarily managed by `imei1`, `imei2`, and `serialNumber`.
- **Reactivation Pattern**: When a product with an existing IMEI is "added", the system checks if `stock == 0`. If so, it updates the existing record (Recompra) instead of creating a new one.
- **Stock Movements**: Every stock change must generate a `StockHistoryEntry` describing the reason and who made the change.

## 3. Sales & POS Logic
- **POS Prerequisite**: A sale in the PDV (POS) MUST be linked to an open `CashSession` (`cashSessionId`).
- **Sale Statuses**:
    - `Finalizada`: Stock is decremented.
    - `Cancelada`: Stock is automatically reverted (incremented back).
- **Payment Methods**: We support split payments. "Aparelho na Troca" (Trade-in) generates a specialized `TradeInEntry` and affects the sale's financial balance.

## 4. Financial & Fees
- **Installments**: There are two modes for credit card fees:
    - **Customer Pays**: Fee added to the total.
    - **Seller Pays**: Fee deducted from the profit (internal calculation).
- **Format**: All monetary values are handled as `number` in the logic and formatted as BRL (`R$`) only in the UI using `formatCurrency`.

## 5. Security & Auditing
- **Permission Profiles**: Access to screens (Dashboard, Stock, etc.) and actions (Modify, Delete) is governed by the `PermissionSet` mapped to the user's profile.
- **Audit Logs**: All sensitive actions (Login, DeleteUser, ManualStockAdjust, SaleCancel) MUST call `addAuditLog` with the appropriate `AuditActionType`.
- **Single Session**: Non-admin users are logged out if another session is opened on a different device (`lastSessionId` check).

## 6. Service Conventions
- **Fire-and-Forget Audit**: Audit logs should be called as `addAuditLog(...).catch(...)` to avoid blocking the main UI flow.
- **Automatic Metadata**: Fields like `createdAt`, `updatedAt`, and `id` (UUID) should be managed by the service layer or DB, not the UI components.

---
*Follow these rules to prevent breaking the synchronization between the frontend state and the backend database.*
