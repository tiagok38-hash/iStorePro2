ALTER TABLE catalog_sections ADD COLUMN sort_order TEXT DEFAULT 'newest';
